# Bio
Tatiana Mac (she/they) is an independent American engineer who works directly with organisations to build clear and coherent products and design systems.

She believes the trifecta of accessibility, performance, and inclusion can work symbiotically to improve our social landscape digitally and physically. When ethically-minded, she thinks technologists can dismantle exclusionary systems in favour of community-focused, inclusive ones.

Tatiana is an open source maintainer, currently focused on building a dictionary called [Self-Defined](https://www.selfdefined.app/). Self-Defined seeks to provide more inclusive, holistic, and fluid definitions to reflect the diverse perspectives of the modern world. The dictionary will eventually include integrated bots and an API to embed into enterprise software.

Never totally pleased with design tools, she designs in browser to bring performant, semantic, and accessible visual narratives into the web. Her current obsessions are optimising variable fonts, converting raster images into to SVGs, and recreating modernist paintings in CSS grid. When she can successfully :q vim, she finds new countries to explore (36 and counting) and designs tech merch at [StyleDotCSS](https://www.styledotcss.com/).

## Relevant Links
[YouTube Playlist / Recorded Talks](https://www.youtube.com/watch?list=PLPhd673abXl7PPmhS4FmuTgPmOyv_xvYy&time_continue=1&v=Hzs_8e3Xhhc&feature=emb_title)
[Website](https://www.tatianamac.com/)
[Twitter](https://www.twitter.com/tatianatmac/)
[CodePen](https://codepen.io/tatianamac/)
[GitHub](https://github.com/tatianamac/)