# Speaker Rider
by [Tatiana Mac](https://www.tatianamac.com/)

Before I'll agree to a speaking event, I try to do as much research I can around the event to ensure it aligns with my ethos. I want to share this in case it's helpful to any other speakers.

👐 Speaking comes with _immense_ privilege. I am grateful to all the conference organisers who have brilliantly hosted me. I would love to continue to exercise this privilege to speak at conferences, and use this privilege to make the landscape more accessible and beneficial to tech's most marginalised and suppressed communities.

😫 I wish I didn't have to, but this is long because I provide a lot of explanations for those of you who never had to consider these things. And I will be honest, most thoughtful conferences I've attended check most of these boxes intrinsically, particularly when conference runners are experienced speakers. They get it.

1️⃣ All of these are based on my own ethos. I don't wish to or attempt to speak on behalf of all conference speakers! Diversity of thought, right? 

🤷🏼‍♀️ At times I will opt to speak at a conference anyway, even if they can't meet all criteria. It usually involves a conversation at the least. I hope that you don't judge me for this, because I know I'm already judging myself for these compromises.

💙 You are welcome to use and adopt this speaker ride as a speaker or as a conference organiser (reframing it as what you might send to a speaker when inviting them). I would appreciate if you gave me a heads up and credited me, because emotional labour is often unpaid and unrecognised.

💸 If you would like, you may also [sponsor me](https://github.com/users/tatianamac/sponsorship) for this and other open source work I do.

## Accommodations/Hosting
### 🛩️/🚋 **Travel expenses covered**
Unless:
- Hosted in my current local city (Portland, Ore., U.S.A.), or
- Video remote!
### 🏨 **Lodging expenses covered**
- For full length of conference.
- For international conferences (outside of U.S.A.), I ask for at least one (1) full day of lodging before the conference.
- You must provide the option to purchase both travel and accommodation on behalf of the speaker. While I opt to book my own plane tickets, the forcing the reimbursement model is exclusionary to folks who cannot front the cost for what is sometimes months.
- You must leave your credit card on file for the hotel. Again, many folks cannot afford a large hold on their credit card, or don't have access to credit cards.
### 💰 **Speaker honorarium**
- For for-profit conferences/events and for-profit companies, I ask for [$/€/£]1000-2000.
- If there are multiple speakers, we must all be paid equally. I do not support celebrity speakers getting paid more.
- If I am the only speaker, the exact number is based on location, ticket pricing, fellowship and scholarship programs, and revenue/philanthropy of your company.
- I will agree upon/determine what that number is in that range based on a complex algorithm. 😉
- I will choose to waive for not-for-profit/community confs where tickets are free/very low priced based on similar criteria above.
### 🎟 **Ticket to full conference**
- I would think this is a given, but some colleagues have been *escorted* on and off stage for conferences they spoke at! They were expected to buy tickets!!!

## Conference Logistics
### 📝 **Strictly-enforced Code of Conduct (CoC)**
- You must have a dedication to protecting the most marginalised and minoritised individuals in this industry.
- Your CoC needs to explicitly call out what abuse is with clear examples (not limited to).
- You must have clearly defined methods for dealing with conflicts when they arise with trained staff to address conflicts and be prepared to appropriately handle complaints. CoCs are only as good as their enforcement.
- Both [Write Speak Code](https://www.writespeakcode.com/code-of-conduct/) and [JSConfEU](https://2019.jsconf.eu/code-of-conduct/) provide excellent CoCs that can serve as strong starting points.
### 🔺 **Physically accessible space for all areas used** 
- All areas that are part of the conference should be accessible. Period. That means: 
  - Attendee seating.
  - Stage, even if you don't *think* you have speakers who require mobility aids. Because again, it needs to be accessible at all points to be accessible. It can't be conditional. Think about how things come up. Think about how we should not burden people to self-identify and plan as much as we can help it.
  - Social events tied to the conference within the venue and outside of the venue. (ESPECIALLY If you use these social events to sell the networking aspects, then they need to be accessible. Period.)
  - Accessibility of space should follow the criteria of the American Disabilities Act and/or equivalent international standards.
### 💬 **Live captioning** 
- I swear this helps EVERYONE. It's not just for hard of hearing folks, it helps people like me who have focus issues and process written info better, it helps non-native speakers, it helps people who got distracted for two seconds.
### 🙎🏾‍♀️ **>1+ enby of colour or woman of colour speaker**
- So that I'm not the token only one! ("Lift as we climb," Angela Davis reminds us.).
- You don't *only* invite marginalised folks speaking about their experiences of marginalisation.
### 👨🏻‍🦳 **No all white panels**
- In general, I would hope that you can diversify your panel across race, gender identity, expression, and orientation, physical and mental ability, etc, and also recognise panels are usually only a few folks.
- Most problematic panels I see are literally *all white* 
### 🔐 **Commitment to attendee/speaker security/safety**
- Security should be provided as needed.
- No selling of data/information, _especially_ not to conference sponsors.
### 🚽 **Gender neutral and accessible bathroom options**
- Especially, ensure that you have an option that is _both_ gender neutral *and* accessible.
### 🔖 **Gender pronoun identification**
- Provide stickers/pins/printed on/writing space for nametags.
- It should be optional for attendees to self-identify, but they should be provided the option.
- They, she, and he at the bare minimum. Options should be combinable (so, like for me, I use both she and they).
- Again, pronouns should be listed on website/printed materials (but always optional). You can get away with just using someone's name if you are uncertain, and they is a better default than anything else, IMHO.
### 💰 **Scholarship program considerations**
- If you have a scholarship program, don't call it "Diversity Scholarship." It reinforces the notion that "diverse" (which is often falsely conflated with only racial diversity) candidates all need charity. Especially when you then photograph them and use them to virtue signal your good. It is gross.
- Call them Scholarships. Be explicit to how you choose candidates and don't make them conduct trauma porn to get tickets.
- Include travel. If you don't include travel, you are intrinsically limiting it to local folks, which isn't exactly providing equitable access to folks who don't live in cities where conferences are typically held. I'm not saying you can't give scholarships, but acknowledge this and call them local ticket scholarships or something.
### 🎙 **Stage set up**
- **Accessible stage** (see above)
- **Wireless microphone** (handheld or microphone)
  - Utilised for all staged aspects of conference (Q&A from audience, workshop speakers, etc).
  - The idea of "my voice is loud enough without a mic" is supremely ableist, and even if you ask the audience, you're relying on people to self-identify their needs which is shitty.
- **Confidence monitor viewable from stage**
  - I need to be able to see my slides so I can present fluidly.
  - I ask for a confidence monitor specifically because most lecterns were not designed for folks my size. I am 1,58m short, so I look like a child or Mr Wilson presenting from behind. Also, what would a shorter or mobility aid-using speaker do?
  - If it's a tiny venue without the rigging, I should be fine with the laptop on a small table; and that table should be accessible.
- **Timer viewable from stage**
  - If you are going to be strict about the timeline, then you need to provide this.
  - You need to enforce this _equitably_. I so often see majority/centred folks allowed to go over (read: white cis het dudes who don't care), but then everyone else has to shorten their timeslot to accommodate. Big. Fat. Nope. If you're going to be strict, be strict with _everyone._
## Intellectual Property
### 📋 **Retain intellectual property and ownership of my content**
- I will allow video recordings/live streams so long as they are accessible (captioned) and free (no paywalls!).
- No censorship of my content, written, verbal, visual.
- No branding of my content (I will not use branded templates, etc.).
### 📈 **Slides in speaker-preferred format (right now, slides.com)**
- I will not convert into any other format. Period. My slides take a ton of time to design and create and I practice using what I'm comfortable with.
### 💻 **Speaker option of presenting from conference computer or their own**
- For my more code-dependent friends, it is super difficult to get your set up right to do dope code demos. Many of my friends develop their own slide infrastructure, have special fonts, or have complex environments set up so they can do what they are. Taking this away from them at the last minute is so, so stressful.
- Providing a laptop, say, for someone who doesn't have one, is critical for accessibility as well.
- Asking someone to present from an operating system (OS) that is not their own, with settings they're not used to, etc, is also stressful.

## Last Thoughts
### 🚶🏼‍♀️ **Reserved right for _force majeure_ without consequence**
- If for any reason your conference, other speakers, sponsors, attendees, third-party vendors, etc become problematic (which I reserve the right to determine), I reserve the right to withdraw from the conference at any point.
- Withdrawal may mean that I no longer want my identity associated with your conference (i.e., videos recorded to be deleted/not published, for example).
- The reason for this is that I feel resistance only works if you take meaningful action. Sometimes that meaningful option is opting out of situations.
- You are responsible for any costs associated with this, not limited to accommodations and travel plan changes.
- I have never had to exercise this right—and hope to never have to. I would imagine no conference organiser would want this either.
- It will be my last resort (sorry for getting that stuck in your head) if all else fails. In most situations, I feel confident we can collaborate to find an effective, less dire solution to the problem.

As with all things, this is a work in progress and will evolve as I learn more about myself and speaking.